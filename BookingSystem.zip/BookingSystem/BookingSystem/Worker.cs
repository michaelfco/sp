using BookingSystem.Model.Manager;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace BookingSystem
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private readonly IBookingManager _bookingManager;

        public Worker(ILogger<Worker> logger, IBookingManager bookingManager)
        {
            _logger = logger;
            _bookingManager = bookingManager;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            var today = new DateTime(2022, 5, 11);
            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    Console.WriteLine("============= S&P Global Hotel Booking System =============");
                   
                    
                    PrintAvailableRooms(_bookingManager.GetAvailableRooms(today));
                    Console.WriteLine("");

                    Console.WriteLine($"Booking room 101...");
                    _bookingManager.AddBooking("Patel", 101, today);
                    if (_bookingManager.IsRoomAvailable(101, today))
                    {
                        Console.WriteLine($"Room 101 is available.");
                        Console.WriteLine($"Patel booked the room 101 for {today.ToShortDateString()}");
                    }
                    else
                        Console.WriteLine($"Room 101 is no available. Please try another room");

                    Console.WriteLine("");
                    PrintAvailableRooms(_bookingManager.GetAvailableRooms(today));
                    

                    Console.WriteLine($"Booking room 203...");
                    _bookingManager.AddBooking("Michael", 203, today);
                    Console.WriteLine($"Michael booked the room 101 for {today.ToShortDateString()}");
                    Console.WriteLine("");

                    PrintAvailableRooms(_bookingManager.GetAvailableRooms(today));

                    Console.WriteLine($"Booking room 101...");
                    _bookingManager.AddBooking("Li", 101, today);

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return;
                }
                _logger.LogInformation("Worker running at: {time}", DateTimeOffset.Now);
                await Task.Delay(1000, stoppingToken);
            }
        }

        private static void PrintAvailableRooms(IEnumerable<int> ar)
        {
            Console.WriteLine("-----Available Rooms:----- ");
            Console.WriteLine(string.Join(",", ar.ToArray()));
            Console.WriteLine("");
        }
    }
}
