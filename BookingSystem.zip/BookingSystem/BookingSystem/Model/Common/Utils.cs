﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookingSystem.Model.Common
{
    public static class Utils
    {
        /// <summary>
        /// initialize list with all rooms
        /// </summary>
        /// <returns></returns>
        public static IEnumerable<int> GetAllRooms()
        {
            List<int> lsAllRooms = new List<int> { 101, 102, 201, 203 };
            return lsAllRooms;
        }
      
    }
}
