﻿using BookingSystem.Model.Classes;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace BookingSystem.Model.Common
{
    /// <summary>
    /// create a kind of session to save data in memory
    /// </summary>
    public static class Session
    {
        public static AsyncLocal<List<Booking>> Data = new AsyncLocal<List<Booking>>();
    }
}
