﻿using BookingSystem.Model;
using BookingSystem.Model.Classes;
using BookingSystem.Model.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace BookingSystem.Model.Manager
{
    public class BookingManager : IBookingManager
    {
        public List<Booking> book = new List<Booking>();

        public void AddBooking(string guest, int room, DateTime date)
        {
            
            if (Session.Data.Value == null)
            {
                book.Add(new Booking { Guest = guest, Room = room, Date = date });               
            }
            else 
            {
               var checkRoom = Session.Data.Value.Where(a => a.Date == date && a.Room == room).ToList();
                if(checkRoom.Count <= 0)
                {
                    book.Add(new Booking { Guest = guest, Room = room, Date = date });
                    
                }
                else
                    throw new Exception($"Room {room} is not available for {date}.");
            }
            if(book.Count > 0)
                Session.Data.Value = book;

        }

        public IEnumerable<int> GetAvailableRooms(DateTime date)
        {
            if (Session.Data.Value != null)
            {
                var rooms = Session.Data.Value.Where(a => a.Date == date).ToList();
                var av = Utils.GetAllRooms().Where(a => !rooms.Exists(b => b.Room == a)).ToList();
                return av;
            }
            else
                return Utils.GetAllRooms();
        }

        public bool IsRoomAvailable(int room, DateTime date)
        {
            var rooms = Session.Data.Value.Where(a => a.Date == date && a.Room == room).ToList();
            if (rooms.Count > 0)
                return true;
            return false;
        }
    }
}
