﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookingSystem.Model.Classes
{
    /// <summary>
    /// object for all booking properties
    /// </summary>
    public class Booking
    {
        public string Guest { get; set; }
        public int Room { get; set; }
        public DateTime? Date { get; set; }


    }

}
